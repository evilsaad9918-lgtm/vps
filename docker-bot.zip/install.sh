#!/bin/bash
set -e
apt-get update
apt-get install -y docker.io python3 python3-venv python3-pip
systemctl enable --now docker
cd "$(dirname "$0")"
docker build -t evm-docker-vps:latest .
python3 -m venv .venv
.venv/bin/pip install --upgrade pip
.venv/bin/pip install -r requirements.txt
[ -f .env ] || cp .env.example .env
echo
echo "Edit .env and add your Discord bot token, admin ID, and VPS public IP."
echo "Then run: .venv/bin/python bot.py"
