import os, secrets, string, re
import docker
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

TOKEN = os.environ["VPS_API_TOKEN"]
SSH_HOST = os.environ["SSH_HOST"]
IMAGE = os.getenv("VPS_IMAGE", "evm-v3-ubuntu:22.04")
MAX_VPS = int(os.getenv("MAX_VPS", "10"))
MEMORY = os.getenv("VPS_MEMORY", "1g")
CPU_QUOTA = int(os.getenv("VPS_CPU_QUOTA", "50000"))
PIDS_LIMIT = int(os.getenv("VPS_PIDS_LIMIT", "256"))
PORT_MIN = int(os.getenv("SSH_PORT_MIN", "22000"))
PORT_MAX = int(os.getenv("SSH_PORT_MAX", "22999"))

client = docker.from_env()
app = FastAPI(title="EVM-V3 VPS Host Agent")

class DeployRequest(BaseModel):
    owner_id: str

def auth(authorization):
    if authorization != f"Bearer {TOKEN}":
        raise HTTPException(401, "Unauthorized")

def container_name(owner):
    if not re.fullmatch(r"\d{5,25}", owner):
        raise HTTPException(400, "Invalid Discord user ID")
    return f"evmv3-{owner}"

def get_container(owner):
    try: return client.containers.get(container_name(owner))
    except docker.errors.NotFound: raise HTTPException(404, "VPS not found")

def used_ports():
    ports = set()
    for c in client.containers.list(all=True, filters={"label": "evmv3.managed=true"}):
        try:
            binding = c.attrs["HostConfig"]["PortBindings"]["22/tcp"]
            if binding: ports.add(int(binding[0]["HostPort"]))
        except Exception: pass
    return ports

@app.get("/health")
def health(): return {"ok": True}

@app.post("/vps")
def deploy(req: DeployRequest, authorization: str = Header(default="")):
    auth(authorization)
    name = container_name(req.owner_id)
    try:
        existing = client.containers.get(name)
        raise HTTPException(409, "You already have a VPS. Use $manage.")
    except docker.errors.NotFound: pass

    managed = client.containers.list(all=True, filters={"label": "evmv3.managed=true"})
    if len(managed) >= MAX_VPS: raise HTTPException(503, "VPS capacity is full. Contact an administrator.")

    available = [p for p in range(PORT_MIN, PORT_MAX + 1) if p not in used_ports()]
    if not available: raise HTTPException(503, "No SSH ports available.")
    port = available[0]
    password = "".join(secrets.choice(string.ascii_letters + string.digits + "!@#%") for _ in range(20))
    username = "vpsuser"
    try:
        c = client.containers.run(
            IMAGE, name=name, detach=True, init=True,
            labels={"evmv3.managed": "true", "evmv3.owner": req.owner_id},
            ports={"22/tcp": ("0.0.0.0", port)},
            environment={"VPS_USERNAME": username, "VPS_PASSWORD": password},
            mem_limit=MEMORY, nano_cpus=CPU_QUOTA * 1000, pids_limit=PIDS_LIMIT,
            cap_drop=["ALL"], cap_add=["CHOWN", "SETUID", "SETGID", "DAC_OVERRIDE", "FOWNER", "SYS_CHROOT", "KILL"],
            security_opt=["no-new-privileges:true"], restart_policy={"Name": "unless-stopped"},
        )
        return {"owner_id": req.owner_id, "ssh_host": SSH_HOST, "ssh_port": port, "username": username, "password": password, "status": c.status}
    except Exception as e:
        raise HTTPException(500, f"Container creation failed: {str(e)[:180]}")

@app.get("/vps/{owner}")
def status(owner: str, authorization: str = Header(default="")):
    auth(authorization); c = get_container(owner)
    c.reload()
    port_data = c.attrs["NetworkSettings"]["Ports"]["22/tcp"][0]
    return {"owner_id": owner, "status": c.status, "ssh_host": SSH_HOST, "ssh_port": int(port_data["HostPort"])}

@app.post("/vps/{owner}/{action}")
def control(owner: str, action: str, authorization: str = Header(default="")):
    auth(authorization); c = get_container(owner)
    if action == "start": c.start()
    elif action == "stop": c.stop(timeout=10)
    elif action == "restart": c.restart(timeout=10)
    else: raise HTTPException(400, "Unsupported action")
    c.reload()
    return {"message": f"VPS {action} completed. Current status: {c.status}", "status": c.status}

@app.delete("/vps/{owner}")
def delete(owner: str, authorization: str = Header(default="")):
    auth(authorization); c = get_container(owner)
    c.remove(force=True, v=True)
    return {"message": "VPS deleted"}

@app.get("/admin/list")
def admin_list(authorization: str = Header(default="")):
    auth(authorization)
    items = []
    for c in client.containers.list(all=True, filters={"label": "evmv3.managed=true"}):
        c.reload()
        labels = c.labels
        port = c.attrs.get("NetworkSettings", {}).get("Ports", {}).get("22/tcp")
        items.append({"owner_id": labels.get("evmv3.owner"), "status": c.status,
                      "ssh_port": int(port[0]["HostPort"]) if port else None})
    return {"items": items}
