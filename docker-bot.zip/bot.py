import os
import re
import logging
from typing import Any

import discord
from discord.ext import commands
import aiohttp
from dotenv import load_dotenv

load_dotenv()

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
RAILWAY_API_TOKEN = os.getenv("RAILWAY_API_TOKEN", "").strip()
RAILWAY_PROJECT_ID = os.getenv("RAILWAY_PROJECT_ID", "").strip()
RAILWAY_ENVIRONMENT_ID = os.getenv("RAILWAY_ENVIRONMENT_ID", "").strip()
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}
PREFIX = os.getenv("PREFIX", "$")
API_URL = "https://backboard.railway.com/graphql/v2"

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("evmlauncher")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)


class RailwayError(Exception):
    pass


async def railway_request(query: str, variables: dict[str, Any] | None = None):
    if not RAILWAY_API_TOKEN:
        raise RailwayError("RAILWAY_API_TOKEN is missing in environment variables.")
    headers = {
        "Authorization": f"Bearer {RAILWAY_API_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {"query": query, "variables": variables or {}}
    timeout = aiohttp.ClientTimeout(total=30)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(API_URL, headers=headers, json=payload) as response:
            body = await response.json(content_type=None)
            if response.status >= 400:
                raise RailwayError(f"Railway API returned HTTP {response.status}.")
            if body.get("errors"):
                message = "; ".join(
                    err.get("message", "Unknown GraphQL error")
                    for err in body["errors"]
                )
                raise RailwayError(message[:900])
            return body.get("data", {})


def admin_only():
    async def predicate(ctx):
        return ctx.author.id in ADMIN_IDS
    return commands.check(predicate)


def valid_identifier(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{1,62}", value))


@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"{PREFIX}help | Railway deployments"
        )
    )


@bot.command(name="help")
async def help_command(ctx):
    embed = discord.Embed(
        title="EVILSAAD RAILWAY DEPLOY BOT",
        description="Deploy and manage Docker-image services in your own Railway project.",
        color=discord.Color.purple()
    )
    embed.add_field(
        name="Commands",
        value=(
            f"`{PREFIX}deploy <service-name> <docker-image>` — create and deploy a service\n"
            f"`{PREFIX}status <service-id>` — show deployment status\n"
            f"`{PREFIX}restart <service-id>` — redeploy the current service\n"
            f"`{PREFIX}delete <service-id>` — permanently delete a service (admin only)\n"
            f"`{PREFIX}help` — show this help"
        ),
        inline=False
    )
    embed.set_footer(text="Railway runs containers/services, not full LXC/KVM Ubuntu VPS instances.")
    await ctx.reply(embed=embed, mention_author=False)


@bot.command(name="deploy")
@admin_only()
async def deploy(ctx, service_name: str, *, docker_image: str):
    if not RAILWAY_PROJECT_ID or not RAILWAY_ENVIRONMENT_ID:
        return await ctx.reply(
            "Configuration missing: set RAILWAY_PROJECT_ID and RAILWAY_ENVIRONMENT_ID in `.env`."
        )
    if not valid_identifier(service_name):
        return await ctx.reply("Invalid service name. Use 2–63 letters, numbers, dots, `_` or `-`.")
    if len(docker_image) > 250 or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/:@-]*", docker_image):
        return await ctx.reply("Docker image name looks invalid. Example: `nginx:alpine`.")

    msg = await ctx.reply(f"⏳ Creating Railway service **{discord.utils.escape_markdown(service_name)}**...")
    try:
        create_query = """
        mutation CreateService($input: ServiceCreateInput!) {
          serviceCreate(input: $input) { id name }
        }
        """
        data = await railway_request(create_query, {
            "input": {
                "projectId": RAILWAY_PROJECT_ID,
                "name": service_name,
                "source": {"image": docker_image}
            }
        })
        service = data["serviceCreate"]
        service_id = service["id"]

        deploy_query = """
        mutation DeployService($serviceId: String!, $environmentId: String!) {
          serviceInstanceDeployV2(serviceId: $serviceId, environmentId: $environmentId)
        }
        """
        await railway_request(deploy_query, {
            "serviceId": service_id,
            "environmentId": RAILWAY_ENVIRONMENT_ID
        })

        embed = discord.Embed(
            title="🚀 Deployment requested",
            color=discord.Color.green()
        )
        embed.add_field(name="Service", value=service.get("name", service_name), inline=True)
        embed.add_field(name="Docker image", value=f"`{docker_image}`", inline=True)
        embed.add_field(name="Service ID", value=f"`{service_id}`", inline=False)
        embed.add_field(name="Status", value="Deployment request sent to Railway.", inline=False)
        await msg.edit(content=None, embed=embed)
    except (RailwayError, KeyError, aiohttp.ClientError) as exc:
        log.exception("Deploy failed")
        await msg.edit(content=f"❌ Deployment failed: `{str(exc)[:800]}`")


@bot.command(name="status")
@admin_only()
async def status(ctx, service_id: str):
    if not RAILWAY_ENVIRONMENT_ID:
        return await ctx.reply("Set `RAILWAY_ENVIRONMENT_ID` in `.env`.")
    query = """
    query ServiceStatus($serviceId: String!, $environmentId: String!) {
      serviceInstance(serviceId: $serviceId, environmentId: $environmentId) {
        id serviceName
        latestDeployment { id status createdAt }
      }
    }
    """
    try:
        data = await railway_request(query, {
            "serviceId": service_id,
            "environmentId": RAILWAY_ENVIRONMENT_ID
        })
        instance = data.get("serviceInstance")
        if not instance:
            return await ctx.reply("No service instance returned. Check the service ID and environment.")
        deployment = instance.get("latestDeployment") or {}
        embed = discord.Embed(title="Railway service status", color=discord.Color.blurple())
        embed.add_field(name="Service", value=instance.get("serviceName") or "Unknown")
        embed.add_field(name="Deployment", value=deployment.get("status") or "No deployment")
        embed.add_field(name="Service ID", value=f"`{service_id}`", inline=False)
        if deployment.get("id"):
            embed.add_field(name="Deployment ID", value=f"`{deployment['id']}`", inline=False)
        if deployment.get("createdAt"):
            embed.add_field(name="Created", value=deployment["createdAt"], inline=False)
        await ctx.reply(embed=embed)
    except (RailwayError, aiohttp.ClientError) as exc:
        await ctx.reply(f"❌ Status lookup failed: `{str(exc)[:800]}`")


@bot.command(name="restart")
@admin_only()
async def restart(ctx, service_id: str):
    if not RAILWAY_ENVIRONMENT_ID:
        return await ctx.reply("Set `RAILWAY_ENVIRONMENT_ID` in `.env`.")
    query = """
    mutation RedeployService($serviceId: String!, $environmentId: String!) {
      serviceInstanceRedeploy(serviceId: $serviceId, environmentId: $environmentId)
    }
    """
    try:
        await railway_request(query, {
            "serviceId": service_id,
            "environmentId": RAILWAY_ENVIRONMENT_ID
        })
        await ctx.reply(f"🔄 Redeploy request sent for service `{service_id}`.")
    except (RailwayError, aiohttp.ClientError) as exc:
        await ctx.reply(f"❌ Redeploy failed: `{str(exc)[:800]}`")


@bot.command(name="delete")
@admin_only()
async def delete_service(ctx, service_id: str):
    # Discord confirmation is required before the destructive API call.
    prompt = await ctx.reply(
        f"⚠️ This permanently deletes service `{service_id}` and its deployments.\n"
        "Reply `CONFIRM` within 20 seconds to continue."
    )

    def check(message):
        return (
            message.author.id == ctx.author.id
            and message.channel.id == ctx.channel.id
            and message.content == "CONFIRM"
        )

    try:
        await bot.wait_for("message", check=check, timeout=20)
    except TimeoutError:
        return await prompt.edit(content="Deletion cancelled (confirmation timed out).")

    query = "mutation DeleteService($id: String!) { serviceDelete(id: $id) }"
    try:
        await railway_request(query, {"id": service_id})
        await prompt.edit(content=f"🗑️ Service `{service_id}` deletion request completed.")
    except (RailwayError, aiohttp.ClientError) as exc:
        await prompt.edit(content=f"❌ Delete failed: `{str(exc)[:800]}`")


@deploy.error
@status.error
@restart.error
@delete_service.error
async def command_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        return await ctx.reply("⛔ You are not authorized to use this command.")
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.reply(f"Missing argument. Use `{PREFIX}help`.")
    if isinstance(error, commands.BadArgument):
        return await ctx.reply(f"Invalid argument. Use `{PREFIX}help`.")
    log.exception("Command error", exc_info=error)
    await ctx.reply("Something went wrong. Check the bot logs.")


if __name__ == "__main__":
    if not DISCORD_TOKEN:
        raise SystemExit("DISCORD_TOKEN is missing. Configure your Railway Variables.")
    if not ADMIN_IDS:
        raise SystemExit("ADMIN_IDS is missing. Add at least one Discord user ID.")
    bot.run(DISCORD_TOKEN)
