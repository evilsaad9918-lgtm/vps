#!/bin/bash
set -e
USER_NAME="${VPS_USERNAME:-vpsuser}"
USER_PASS="${VPS_PASSWORD:?VPS_PASSWORD is required}"
if ! id "$USER_NAME" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$USER_NAME"
fi
echo "$USER_NAME:$USER_PASS" | chpasswd
mkdir -p /run/sshd
# Password authentication is enabled; root login remains disabled.
sed -i 's/^#\?PasswordAuthentication .*/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/^#\?PermitRootLogin .*/PermitRootLogin no/' /etc/ssh/sshd_config
sed -i 's/^#\?UsePAM .*/UsePAM yes/' /etc/ssh/sshd_config
exec /usr/sbin/sshd -D -e
