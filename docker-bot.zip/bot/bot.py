import os, aiohttp, discord
from discord.ext import commands

TOKEN = os.environ["DISCORD_TOKEN"]
API_URL = os.environ["VPS_API_URL"].rstrip("/")
API_TOKEN = os.environ["VPS_API_TOKEN"]
ADMIN_ROLE_ID = int(os.getenv("ADMIN_ROLE_ID", "0"))
PREFIX = os.getenv("COMMAND_PREFIX", "$")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)

async def api(method, path, payload=None):
    headers = {"Authorization": f"Bearer {API_TOKEN}"}
    timeout = aiohttp.ClientTimeout(total=90)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.request(method, API_URL + path, json=payload, headers=headers) as r:
            data = await r.json()
            if r.status >= 400:
                raise RuntimeError(data.get("detail", f"API error {r.status}"))
            return data

def is_admin(ctx):
    return ctx.guild and any(r.id == ADMIN_ROLE_ID for r in ctx.author.roles) if ADMIN_ROLE_ID else False

class ManageView(discord.ui.View):
    def __init__(self, owner_id):
        super().__init__(timeout=900)
        self.owner_id = owner_id

    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("This VPS panel belongs to another member.", ephemeral=True)
            return False
        return True

    async def action(self, interaction, operation):
        await interaction.response.defer(ephemeral=True)
        try:
            result = await api("POST", f"/vps/{self.owner_id}/{operation}")
            await interaction.followup.send(result.get("message", "Done."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Error: {e}", ephemeral=True)

    @discord.ui.button(label="START", style=discord.ButtonStyle.success, emoji="🟢")
    async def start(self, interaction, button): await self.action(interaction, "start")

    @discord.ui.button(label="STOP", style=discord.ButtonStyle.danger, emoji="🔴")
    async def stop(self, interaction, button): await self.action(interaction, "stop")

    @discord.ui.button(label="RESTART", style=discord.ButtonStyle.primary, emoji="🔄")
    async def restart(self, interaction, button): await self.action(interaction, "restart")

    @discord.ui.button(label="STATUS", style=discord.ButtonStyle.secondary, emoji="📊")
    async def status(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        try:
            r = await api("GET", f"/vps/{self.owner_id}")
            await interaction.followup.send(f"**Status:** {r['status']}\n**SSH:** `{r['ssh_host']}:{r['ssh_port']}`", ephemeral=True)
        except Exception as e: await interaction.followup.send(f"Error: {e}", ephemeral=True)

    @discord.ui.button(label="DELETE VPS", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def delete(self, interaction, button):
        await interaction.response.defer(ephemeral=True)
        try:
            await api("DELETE", f"/vps/{self.owner_id}")
            await interaction.followup.send("VPS deleted. Its data volume was also removed.", ephemeral=True)
            self.stop()
            for item in self.children: item.disabled = True
            await interaction.message.edit(view=self)
        except Exception as e: await interaction.followup.send(f"Error: {e}", ephemeral=True)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

@bot.command()
async def deploy(ctx):
    if ctx.guild is None:
        return await ctx.reply("Run $deploy in the server, not in DM.")
    await ctx.reply("⏳ Creating your Ubuntu container. I will DM the SSH details when ready.")
    try:
        data = await api("POST", "/vps", {"owner_id": str(ctx.author.id)})
        msg = (
            "🚀 **EVM-V3 VPS DEPLOYED**\n\n"
            f"**OS:** Ubuntu 22.04\n"
            f"**Host:** `{data['ssh_host']}`\n"
            f"**SSH Port:** `{data['ssh_port']}`\n"
            f"**Username:** `{data['username']}`\n"
            f"**Password:** ||`{data['password']}`||\n\n"
            "Connect: `ssh USERNAME@HOST -p PORT`\n"
            "Use `$manage` in the server for controls. Save your password now; it is shown only once."
        ).replace("USERNAME", data["username"]).replace("HOST", data["ssh_host"]).replace("PORT", str(data["ssh_port"]))
        await ctx.author.send(msg)
    except discord.Forbidden:
        await ctx.author.send("I couldn't DM you. Enable server-member DMs, then run `$deploy` again.")
    except Exception as e:
        await ctx.author.send(f"VPS deployment failed: {e}")

@bot.command()
async def manage(ctx):
    try:
        await api("GET", f"/vps/{ctx.author.id}")
        await ctx.author.send("**EVM-V3 VPS Manager** — choose an action:", view=ManageView(ctx.author.id))
        if ctx.guild: await ctx.reply("Check your DMs for the VPS management panel.")
    except Exception as e:
        await ctx.reply(f"No VPS found or API error: {e}")

@bot.command()
async def admin(ctx):
    if not is_admin(ctx):
        return await ctx.reply("Admin role required.")
    try:
        data = await api("GET", "/admin/list")
        lines = [f"`{x['owner_id']}` — {x['status']} — SSH `{x['ssh_port']}`" for x in data["items"]]
        await ctx.author.send("**Active VPS instances**\n" + ("\n".join(lines) or "None"))
    except Exception as e: await ctx.reply(f"Error: {e}")

@bot.command()
async def help(ctx):
    await ctx.reply("Commands: `$deploy` — create your Ubuntu VPS; `$manage` — open your private DM controls.")

bot.run(TOKEN)
