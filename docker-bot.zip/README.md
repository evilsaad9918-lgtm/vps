# EVILSAAD Railway Deploy Bot

A Discord bot that creates and manages Docker-image services in a Railway project through Railway's GraphQL API.

## Important limitation
Railway deploys containerized services. This bot does **not** create traditional LXC/KVM virtual machines or a full Ubuntu VPS with unrestricted root/system-level access.

## Commands
- `$help`
- `$deploy <service-name> <docker-image>` — admin only; creates a service and requests deployment.
- `$status <service-id>` — admin only.
- `$restart <service-id>` — admin only; redeploys the current service.
- `$delete <service-id>` — admin only; requires typing `CONFIRM`.

Example:
`$deploy web nginx:alpine`

## Deploy this Discord bot on Railway
1. Upload this folder to a GitHub repository.
2. In Railway, create a project and deploy the repository as a service.
3. Add the environment variables from `.env.example` in the bot service's Variables tab.
4. Create a Railway API token with the required project/service/deployment permissions.
5. Enable the **Message Content Intent** for your Discord application in the Discord Developer Portal.
6. Deploy/redeploy the bot service.

## Required Railway values
- `RAILWAY_API_TOKEN`: API token for the Railway account/project that will own the services.
- `RAILWAY_PROJECT_ID`: target project ID where the bot creates services.
- `RAILWAY_ENVIRONMENT_ID`: target environment ID, commonly the production environment.
- `DISCORD_TOKEN`: Discord bot token.
- `ADMIN_IDS`: comma-separated Discord user IDs allowed to manage deployments.

Keep all tokens private. Never paste them into public chats or commit `.env` to GitHub.

## Notes
- Railway usage, resource limits, billing, and service availability are controlled by your Railway account and plan.
- The bot creates services from Docker image names. Use images from registries supported by Railway.
- A service may take time to build and become active. Check deployment status in Railway if needed.
