# EVM-V3 Discord VPS Bot

Discord members use `$deploy` in your server. The bot privately DMs SSH credentials.
`$manage` sends a private button panel with START, STOP, RESTART, STATUS and DELETE.

## Architecture — important
Railway hosts the Discord bot only. A separate Linux server with Docker Engine is required
to create and run the member containers. Railway does not provide a general privileged
Docker host for spawning nested VPS containers. Members do not need to visit Railway.

## 1. Requirements
- Discord application/bot with **Message Content Intent** enabled.
- Railway project for the bot.
- Separate Ubuntu 22.04/24.04 Docker host with a public IP.
- DNS name and HTTPS reverse proxy (Caddy/Nginx) in front of the host-agent API.
- Open TCP SSH port range (default 22000–22999) from the internet to the Docker host.

## 2. Build the Ubuntu VPS image on the Docker host
Copy `vps-image/` to the Docker host, then run:
```bash
cd vps-image
docker build -t evm-v3-ubuntu:22.04 .
```

## 3. Run the host agent on the Docker host
Copy `host-agent/` to the host. Create `host-agent/.env` from `.env.example`.
Set `VPS_API_TOKEN` to a long random secret and `SSH_HOST` to the public hostname/IP.
Then:
```bash
cd host-agent
docker compose up -d --build
```
Put HTTPS in front of port 8000. Do not expose the agent over plain public HTTP.
The agent needs Docker socket access, which is effectively host-root access. Keep it
patched, restrict API access with the secret, firewall it, and never share the token.

## 4. Configure Railway bot
Upload this project to a GitHub repository. In Railway, deploy using the included
`railway.json` / `bot/Dockerfile`, then add these variables:
- `DISCORD_TOKEN`
- `VPS_API_URL` (HTTPS URL of host-agent)
- `VPS_API_TOKEN` (same secret as host agent)
- `ADMIN_ROLE_ID` (optional Discord role ID; `0` disables `$admin`)

In Discord Developer Portal enable **Message Content Intent**. Invite the bot with
View Channels, Send Messages, Read Message History, and Use Application Commands permissions.
The bot must be able to DM members; members may need to allow server-member DMs.

## 5. Commands
- `$deploy` — create one Ubuntu 22.04 container per Discord user and DM SSH credentials.
- `$manage` — DM a private control panel.
- `$admin` — list managed containers (requires configured admin role).

SSH format:
```bash
ssh vpsuser@YOUR_HOST -p YOUR_PORT
```

SSHX:
After connecting over SSH, the member can install/run SSHX using the current official
instructions at https://sshx.io/ . SSHX is a third-party service and its session link
can grant terminal access to whoever possesses it; only share it with trusted people.

## Security and limitations
- This is a starter project, not a hardened commercial multi-tenant hosting platform.
- Containers are resource-limited, non-privileged, and do not mount host directories.
- It is not a full virtual machine: it is an Ubuntu container with SSH, not a KVM VPS.
- Deleting a VPS removes its container and writable data. This starter does not provide backups.
- Restrict who can use `$deploy` using Discord channel permissions or add an allowlist before
  opening the bot to a public server. Set conservative RAM/CPU/count limits.
- The host agent has Docker socket access. Treat it as highly privileged infrastructure.
- Add TLS, firewall rules, monitoring, abuse controls, per-user quotas, and backups before
  production use. Never run unknown images or grant privileged mode to member containers.
