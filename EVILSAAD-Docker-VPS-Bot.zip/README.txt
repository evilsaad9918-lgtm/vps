EVILSAAD Docker VPS Discord Bot

Commands:
  $deploy
  $manage
  $create @user 4 1 30       (admin only: RAM GB, CPU cores, disk GB request)
  $delete-vps @user          (admin only)
  $help

Install on a fresh Ubuntu 22.04/24.04 Docker host:
  chmod +x install.sh
  sudo ./install.sh
  nano .env
  .venv/bin/python bot.py

Important:
- This creates Ubuntu Docker containers, NOT KVM/VM VPS instances.
- Docker containers share the host kernel. Do not expose this as equivalent to a full VPS.
- `storage_opt=size=...` disk quota requires Docker overlay2 and a backing filesystem/configuration that supports it. If unsupported, container creation will fail; configure and test storage quotas before offering disk plans.
- Open the SSH port range (default starts at TCP 22000) in your VPS provider firewall.
- Never give users Docker socket access, privileged mode, host networking, or host mounts.
- Enable Discord Message Content Intent in the Developer Portal.
- Keep .env private. Use a dedicated host and firewall.
- SSHX button currently provides SSH connection instructions; after connecting, run `sshx` in the container if you install the SSHX client.
