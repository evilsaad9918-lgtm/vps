import os, re, sqlite3, secrets, string, subprocess
import discord
from discord.ext import commands
import docker
from docker.errors import DockerException, NotFound, APIError
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_BOT_TOKEN", "").strip()
ADMIN_IDS = {int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
PREFIX = "$"
IMAGE = os.getenv("VPS_IMAGE", "evm-docker-vps:latest")
SSH_PORT_START = int(os.getenv("SSH_PORT_START", "22000"))
DB = "vps.db"

if not TOKEN:
    raise RuntimeError("Set DISCORD_BOT_TOKEN in .env")
if not ADMIN_IDS:
    raise RuntimeError("Set at least one Discord ID in ADMIN_IDS in .env")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)
dock = docker.from_env()

def db():
    c = sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS vps
        (user_id INTEGER PRIMARY KEY, container_id TEXT NOT NULL,
         container_name TEXT NOT NULL, ram INTEGER NOT NULL,
         cpu REAL NOT NULL, disk INTEGER NOT NULL, ssh_port INTEGER NOT NULL)""")
    c.commit()
    return c

def is_admin(ctx):
    return ctx.author.id in ADMIN_IDS

def get_vps(user_id):
    c = db()
    row = c.execute("SELECT user_id,container_id,container_name,ram,cpu,disk,ssh_port FROM vps WHERE user_id=?", (user_id,)).fetchone()
    c.close()
    return row

def save_vps(row):
    c = db()
    c.execute("INSERT OR REPLACE INTO vps VALUES (?,?,?,?,?,?,?)", row)
    c.commit()
    c.close()

def remove_vps(user_id):
    c = db()
    c.execute("DELETE FROM vps WHERE user_id=?", (user_id,))
    c.commit()
    c.close()

def make_password(n=18):
    chars = string.ascii_letters + string.digits + "!@#$%&*"
    return ''.join(secrets.choice(chars) for _ in range(n))

def next_port():
    used = set()
    c = db()
    used.update(r[0] for r in c.execute("SELECT ssh_port FROM vps"))
    c.close()
    p = SSH_PORT_START
    while p in used:
        p += 1
    return p

def create_container(user_id, ram, cpu, disk):
    if get_vps(user_id):
        raise ValueError("This user already has a VPS. Use $manage.")
    if not (1 <= ram <= 32 and 0.5 <= cpu <= 8 and 5 <= disk <= 200):
        raise ValueError("Limits: RAM 1-32 GB, CPU 0.5-8 cores, disk request 5-200 GB.")
    port = next_port()
    name = f"evm-vps-{user_id}"
    password = make_password()
    # Disk quota is requested through overlay2; it works only on supported Docker hosts.
    container = dock.containers.run(
        IMAGE, name=name, detach=True, init=True,
        mem_limit=f"{ram}g", nano_cpus=int(cpu * 1_000_000_000),
        ports={"22/tcp": ("0.0.0.0", port)},
        environment={"ROOT_PASSWORD": password},
        restart_policy={"Name": "unless-stopped"},
        storage_opt={"size": f"{disk}G"},
        cap_drop=["ALL"], cap_add=["CHOWN","SETUID","SETGID","DAC_OVERRIDE","FOWNER","NET_BIND_SERVICE"],
        security_opt=["no-new-privileges:true"],
        pids_limit=512
    )
    save_vps((user_id, container.id, name, ram, cpu, disk, port))
    return password, port

async def deliver_credentials(user, password, port):
    try:
        await user.send(
            f"Your Docker VPS is ready.\nHost: `{os.getenv('VPS_PUBLIC_IP','YOUR_SERVER_IP')}`\n"
            f"Port: `{port}`\nUsername: `root`\nPassword: `{password}`\n"
            "Connect with SSH: `ssh root@YOUR_SERVER_IP -p PORT` (replace placeholders)."
        )
    except discord.Forbidden:
        pass

class ManageView(discord.ui.View):
    def __init__(self, owner_id):
        super().__init__(timeout=180)
        self.owner_id = owner_id

    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id and interaction.user.id not in ADMIN_IDS:
            await interaction.response.send_message("This VPS menu is not yours.", ephemeral=True)
            return False
        return True

    def row(self):
        return get_vps(self.owner_id)

    @discord.ui.button(label="Start", style=discord.ButtonStyle.success)
    async def start(self, interaction, button):
        row = self.row()
        if not row: return await interaction.response.send_message("VPS record not found.", ephemeral=True)
        try:
            dock.containers.get(row[1]).start()
            await interaction.response.send_message("VPS started.", ephemeral=True)
        except (NotFound, APIError) as e:
            await interaction.response.send_message(f"Could not start VPS: {e}", ephemeral=True)

    @discord.ui.button(label="Stop", style=discord.ButtonStyle.danger)
    async def stop(self, interaction, button):
        row = self.row()
        if not row: return await interaction.response.send_message("VPS record not found.", ephemeral=True)
        try:
            dock.containers.get(row[1]).stop()
            await interaction.response.send_message("VPS stopped.", ephemeral=True)
        except (NotFound, APIError) as e:
            await interaction.response.send_message(f"Could not stop VPS: {e}", ephemeral=True)

    @discord.ui.button(label="Reinstall", style=discord.ButtonStyle.secondary)
    async def reinstall(self, interaction, button):
        row = self.row()
        if not row: return await interaction.response.send_message("VPS record not found.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            old = dock.containers.get(row[1])
            old.remove(force=True)
            password, port = create_container(row[0], row[3], row[4], row[5])
            await interaction.followup.send(f"Reinstalled. New root password: `{password}` | SSH port: `{port}`", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Reinstall failed: {e}", ephemeral=True)

    @discord.ui.button(label="SSHX / Connect", style=discord.ButtonStyle.primary)
    async def sshx(self, interaction, button):
        row = self.row()
        if not row: return await interaction.response.send_message("VPS record not found.", ephemeral=True)
        host = os.getenv("VPS_PUBLIC_IP", "YOUR_SERVER_IP")
        await interaction.response.send_message(
            f"SSH connection:\n`ssh root@{host} -p {row[6]}`\n"
            "For SSHX, first connect to the VPS, then run `sshx` in its terminal. "
            "Install the SSHX client inside the container if it is not already available.",
            ephemeral=True
        )

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} | Docker VPS bot online")

@bot.command(name="deploy")
async def deploy(ctx):
    if get_vps(ctx.author.id):
        return await ctx.reply("You already have a VPS. Use `$manage`.")
    await ctx.reply("Creating your default VPS: 4 GB RAM, 1 CPU core, 30 GB requested disk...")
    try:
        password, port = create_container(ctx.author.id, 4, 1, 30)
        await ctx.reply("VPS created. I am sending connection details in DM.")
        await deliver_credentials(ctx.author, password, port)
    except Exception as e:
        await ctx.reply(f"Deployment failed: `{e}`")

@bot.command(name="manage")
async def manage(ctx):
    row = get_vps(ctx.author.id)
    if not row:
        return await ctx.reply("No VPS found. Use `$deploy`.")
    await ctx.reply(
        f"**Your VPS**\nRAM: {row[3]} GB | CPU: {row[4]} core(s) | Disk request: {row[5]} GB\n"
        f"SSH port: `{row[6]}`\nChoose an action:",
        view=ManageView(ctx.author.id)
    )

@bot.command(name="create")
async def admin_create(ctx, member: discord.Member = None, ram: int = 4, cpu: float = 1, disk: int = 30):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    if member is None: return await ctx.reply("Usage: `$create @user 4 1 30`")
    try:
        password, port = create_container(member.id, ram, cpu, disk)
        await ctx.reply(f"Created VPS for {member.mention}. Credentials are sent by DM if their DMs are open.")
        await deliver_credentials(member, password, port)
    except Exception as e:
        await ctx.reply(f"Create failed: `{e}`")

@bot.command(name="delete-vps")
async def delete_vps(ctx, member: discord.Member = None):
    if not is_admin(ctx): return await ctx.reply("Admin only.")
    if member is None: return await ctx.reply("Usage: `$delete-vps @user`")
    row = get_vps(member.id)
    if not row: return await ctx.reply("That user has no VPS.")
    try:
        try: dock.containers.get(row[1]).remove(force=True, v=True)
        except NotFound: pass
        remove_vps(member.id)
        await ctx.reply(f"Deleted VPS for {member.mention}. Container data/volumes were removed.")
    except Exception as e:
        await ctx.reply(f"Delete failed: `{e}`")

@bot.command(name="help")
async def help_cmd(ctx):
    await ctx.reply(
        "**Docker VPS Bot Commands**\n"
        "`$deploy` — deploy default 4 GB / 1 core / 30 GB request\n"
        "`$manage` — Start, Stop, Reinstall, SSHX/Connect\n"
        "`$create @user RAM CPU DISK` — admin only\n"
        "`$delete-vps @user` — admin only"
    )

try:
    bot.run(TOKEN)
except DockerException as e:
    print(f"Docker connection error: {e}")
